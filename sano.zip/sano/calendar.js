WinJS.Namespace.define("Controls", {
    Calendar : WinJS.Class.define(
//constructor
function (element, options) {
this.element = element || document.createElement("div");
this.element.className = "control-calendar";
this.element.winControl = this;
console.log;
)
