$(document).ready(function() {
       $('birthdate').birthdate({ changeMonth: true, changeYear: true});

});
