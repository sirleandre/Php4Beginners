<?php 
$text = "Hello World.";
$sum = 10 + 20 ;
//echo $sum;

$num1 = 100;
$num2 = 50;
$num3 = 2;

$res = ($num1 + $num2) / $num3;
//echo $res;

$number1 = 10;
$number2 = 3;

$result = $number1 % $number2 ;
//echo $result;

$number1 = 10;

$number1++;

echo $number1;


?>
<input type="text" value="<?php echo $text; ?>">
